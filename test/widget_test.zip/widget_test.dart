// Basic Flutter widget smoke test for CrashAid app.
// Tests that the app launches without crashing.

import 'package:flutter_test/flutter_test.dart';
import 'package:crashaid/main.dart';

void main() {
  testWidgets('App launches smoke test', (WidgetTester tester) async {
    // Build the app and trigger a frame.
    await tester.pumpWidget(const CrashAidApp());
  });
}